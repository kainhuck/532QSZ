#!/usr/bin/python3
# -*- coding: utf-8 -*-

class DepthValueException(Exception):
    def __str__(self):
        return "DEPTH的值只能为1或2, 请去VALUES.py文件下修改"
