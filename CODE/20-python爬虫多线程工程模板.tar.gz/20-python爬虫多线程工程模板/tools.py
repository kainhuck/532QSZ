#!/usr/bin/python3
# -*- coding: utf-8 -*-
'''
该文件为主文件提供工具
'''

import time
import os

from queue import Queue
from VALUES import TIME_OUT


class Loggit(object):
    '''
    装饰器,负责记录日志
    '''

    def __init__(self, logFile="kainSpider.log"):
        self.logFile = "Log/" + logFile
        if not os.path.exists("Log"):
            os.mkdir("Log")
        if not os.path.exists("Log/" + logFile):
            os.mknod("Log/" + logFile)

    def __call__(self, func):
        def inner(*args, **kwargs):
            now = time.ctime()
            msg = " {} 函数在 {} 被执行\n".format(func.__name__, now)
            with open(self.logFile, 'a') as f:
                f.write(msg)
            temp = func(*args, **kwargs)
            end = time.ctime()
            msg = " {} 函数在 {} 执行结束\n".format(func.__name__, end)
            with open(self.logFile, 'a') as f:
                f.write(msg)

            return temp

        return inner


@Loggit()
def initUrlQueue(maxQueueSize=1000):
    '''
    这个函数请先执行
    初始化URL队列
    '''
    return Queue(maxQueueSize)

@Loggit()
def initFinalQueue(maxQueueSize=30000):
    '''
    这个函数初始化的队列用于存放爬取获得的URL,
    如果选择的是第一次则不需要调用该函数
    '''
    return Queue(maxQueueSize)

@Loggit()
def putToUrlQueue(queue):
    "向队列添加URL"
    for i in range(1, 291):
        url = "http://news.zstu.edu.cn/lgyw1/" + str(i) + ".htm"
        queue.put(url, timeout=TIME_OUT)

    queue.put("http://news.zstu.edu.cn/lgyw1.htm")