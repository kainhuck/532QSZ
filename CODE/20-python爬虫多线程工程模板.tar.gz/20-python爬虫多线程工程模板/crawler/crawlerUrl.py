#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests
import random
from VALUES import TIME_OUT, user_agent
from lxml import etree


class CrawlerUrl(object):
    '''
    用于获取URL,
    如果选择的是一层,则不需要实现这个类,
    '''

    def __init__(self, urlQueue, finalUrlQueue):
        self.queue = urlQueue
        self.finalUrlQueue = finalUrlQueue

    def run(self):
        while not self.queue.empty():
            url = self.queue.get(timeout=TIME_OUT)
            headers = {'User-Agent': random.choice(user_agent)}
            try:
                r = requests.get(url, headers=headers, timeout=TIME_OUT)
                r.status_code = r.apparent_encoding
                selector = etree.HTML(r.text)
                newsLinks = selector.xpath('//div[@class="Hlist"]/a/@href')
                for each in newsLinks:
                    if each[:3] == "../":
                        each = each[3:]
                    url = "http://news.zstu.edu.cn/" + each
                    self.finalUrlQueue.put(url, timeout=TIME_OUT)
            except Exception as e:
                print("Error")