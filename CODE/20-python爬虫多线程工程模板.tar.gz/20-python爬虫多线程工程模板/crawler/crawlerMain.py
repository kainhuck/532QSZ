#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests
import random
from VALUES import TIME_OUT, user_agent, MySQLPass
from lxml import etree
import chardet
from ORM import Mysql


class CrawlerMain(object):
    '''
    爬虫代码写在这里
    '''

    def __init__(self, urlQueue):
        self.queue = urlQueue

    def run(self):
        while not self.queue.empty():
            url = self.queue.get(timeout=TIME_OUT)
            headers = {'User-Agent': random.choice(user_agent)}
            try:
                r = requests.get(url, headers=headers, timeout=TIME_OUT)
                code = chardet.detect(r.content)
                selector = etree.HTML(r.content.decode(code['encoding']))
                newsTitles = selector.xpath('//div[@class="news_tangter"]/text()')
                for each in newsTitles:
                    # print(each)  # 存入数据库操作
                    sql = 'INSERT INTO spider (newsname) VALUES ("%s");' % each
                    # print(sql)
                    with Mysql(**MySQLPass) as m:
                        m.executeSql(sql)
            except Exception as e:
                print("Error:", e)
