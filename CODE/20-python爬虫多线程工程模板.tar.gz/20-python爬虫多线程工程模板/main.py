#!/usr/bin/python3
# -*- coding: utf-8 -*-

'''
执行脚本之前请先将目标URL填入urlQueue
'''
from tools import *
from VALUES import threadNum, threadList, DEPTH
from genSpider import genSpider
from Error import *

SpiderThread = genSpider()


def main():
    urlQueue = initUrlQueue()
    putToUrlQueue(urlQueue)

    if DEPTH == 2:
        finalUrlQueue = initFinalQueue()

        for i in range(threadNum):
            name = "Thread-" + str(i + 1)
            temp = SpiderThread(name, urlQueue, finalUrlQueue)
            threadList.append(temp)
    elif DEPTH == 1:
        for i in range(threadNum):
            name = "Thread-" + str(i + 1)
            temp = SpiderThread(name, urlQueue)
            threadList.append(temp)
    else:
        raise DepthValueException

    # 开启线程
    for thread in threadList:
        thread.start()

    # 等待线程结束
    for thread in threadList:
        thread.join()

    print("爬取结束")


if __name__ == '__main__':
    main()
