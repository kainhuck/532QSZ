#!/usr/bin/python3
# -*- coding: utf-8 -*-

'''
class SpiderThread(Thread):
    def __init__(self, threadName, urlQueue):
        Thread.__init__(self)
        self.threadName = threadName
        self.urlQueue = urlQueue
        self.spider = Crawler(urlQueue)

    def run(self) -> None:
        print("%s开始执行..." % self.threadName)
        self.spider.run()
        print("%s执行结束..." % self.threadName)
'''
from threading import Thread
from crawler.crawlerUrl import CrawlerUrl
from crawler.crawlerMain import CrawlerMain
from VALUES import DEPTH
from Error import *

def genSpider():
    '''
    定义类工厂,用于产生线程主类
    '''
    def __init__v1(self, threadName, urlQueue):
        Thread.__init__(self)
        self.threadName = threadName
        self.urlQueue = urlQueue
        self.spider = CrawlerMain(urlQueue)

    def __init__v2(self, threadName, urlQueue, finalQueue):
        Thread.__init__(self)
        self.threadName = threadName
        self.urlQueue = urlQueue
        self.finalQueue = finalQueue
        self.spider = CrawlerMain(finalQueue)
        self.spiderURL = CrawlerUrl(urlQueue, finalQueue)

    def run_v1(self) -> None:
        print("%s开始执行..." % self.threadName)
        self.spider.run()
        print("%s执行结束..." % self.threadName)

    def run_v2(self) -> None:
        print("%s开始执行..." % self.threadName)
        self.spiderURL.run()
        self.spider.run()
        print("%s执行结束..." % self.threadName)

    if DEPTH == 1:
        return type("SpiderThread", (Thread,), {
            "__init__": __init__v1,
            "run": run_v1
        })
    elif DEPTH == 2:
        return type("SpiderThread", (Thread,), {
            "__init__": __init__v2,
            "run": run_v2
        })
    else:
        raise DepthValueException
